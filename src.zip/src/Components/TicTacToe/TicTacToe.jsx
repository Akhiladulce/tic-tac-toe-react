import React, { useState } from 'react';
import './TicTacToe.css';
import circle_icon from '../Assets/circle.png';
import cross_icon from '../Assets/cross.png';

const TicTacToe = () => {
  const [board, setBoard] = useState(Array(9).fill('')); // State for the game board
  const [count, setCount] = useState(0);
  const [lock, setLock] = useState(false);
  const [winner, setWinner] = useState(null);

  const checkWinner = () => {
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];
    for (let i = 0; i < lines.length; i++) {
      const [a, b, c] = lines[i];
      if (board[a] && board[a] === board[b] && board[a] === board[c]) {
        setWinner(board[a]);
        setLock(true); // Lock the board after a win
        return;
      }
    }

    // Check if 'x' or 'o' has 3 in a row
    const threeInRowX = board[0] === 'x' && board[1] === 'x' && board[2] === 'x';
    const threeInRowO = board[0] === 'o' && board[1] === 'o' && board[2] === 'o';
    if (threeInRowX || threeInRowO) {
      setWinner(threeInRowX ? 'x' : 'o');
      setLock(true); // Lock the board after a win
      return;
    }

    if (count === 9 && !winner) { // Check for a tie if no winner is declared yet
      setWinner('draw'); // Set winner as 'draw' in case of a tie
      setLock(true); // Lock the board after a tie
    }
  };

  const handleClick = (index) => {
    if (lock || board[index]) {
      return;
    }
    const newBoard = [...board];
    newBoard[index] = count % 2 === 0 ? 'x' : 'o';
    setBoard(newBoard);
    setCount(count + 1);
    checkWinner();
  };

  const resetGame = () => {
    setBoard(Array(9).fill(''));
    setCount(0);
    setLock(false);
    setWinner(null); // Reset winner declaration
  };

  const renderCell = (index) => {
    if (board[index] === 'x') {
      return <img src={cross_icon} alt="cross" />;
    } else if (board[index] === 'o') {
      return <img src={circle_icon} alt="circle" />;
    } else {
      return null;
    }
  };

  return (
    <div className='container'>
      <h1 className="title">Tic Tac Toe Game In React</h1>
      <div className="board">
        {[0, 1, 2].map((row) => (
          <div key={row} className={`row${row + 1}`}>
            {[0, 1, 2].map((col) => (
              <div key={row * 3 + col} className="boxes" onClick={() => handleClick(row * 3 + col)}>
                {renderCell(row * 3 + col)}
              </div>
            ))}
          </div>
        ))}
      </div>
      {winner && winner !== 'draw' && (
        <div className="winner-declaration-big">{`Player ${winner.toUpperCase()} wins! Congratulations!`}</div>
      )}
      {winner === 'draw' && (
        <div className="winner-declaration-big">It's a draw!</div>
      )}
      <button className="reset" onClick={resetGame}>Reset</button>
    </div>
  );
};

export default TicTacToe;
